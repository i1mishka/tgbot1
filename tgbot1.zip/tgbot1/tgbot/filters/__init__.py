from .admin import AdminFilter

filters = (
    AdminFilter,
)
